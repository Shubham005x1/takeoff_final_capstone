package content

import (
	"context"
	"encoding/json"
	"fmt"
	"log"
	"net/http"
	"time"

	"cloud.google.com/go/firestore"
	secretmanager "cloud.google.com/go/secretmanager/apiv1"
	"cloud.google.com/go/secretmanager/apiv1/secretmanagerpb"
	"github.com/dgrijalva/jwt-go"
	"golang.org/x/crypto/bcrypt"
	"google.golang.org/api/iterator"
)

const (
	projectID = "capstore-takeoff"
)

// LoginRequest represents the structure of the login request JSON.
type LoginRequest struct {
	Email    string `json:"email"`
	Password string `json:"password"`
}

// User represents the user data structure in Firestore.
type User struct {
	Email    string `firestore:"Email"`
	Password string `firestore:"Password"`
}

// Login handles the HTTP request for user login.
func Login(w http.ResponseWriter, r *http.Request) {
	ctx := context.Background()
	var loginReq LoginRequest

	// Set up Firestore client
	firestoreClient, err := firestore.NewClient(ctx, projectID)
	if err != nil {
		log.Fatalf("Failed to create Firestore client: %v", err)
	}
	defer firestoreClient.Close()

	// Parse request body
	if err := json.NewDecoder(r.Body).Decode(&loginReq); err != nil {
		http.Error(w, "Invalid request body", http.StatusBadRequest)
		return
	}

	// Retrieve user data from Firestore
	user, err := getUserByEmail(ctx, firestoreClient, loginReq.Email)
	if err != nil {
		http.Error(w, "Invalid User Please Provide Valid Email/Password", http.StatusUnauthorized)
		return
	}
	log.Printf("User : %v", user)
	// Check if the provided password matches the stored hashed password
	err = bcrypt.CompareHashAndPassword([]byte(user.Password), []byte(loginReq.Password))
	if err != nil {
		http.Error(w, "Invalid email or password", http.StatusUnauthorized)
		return
	}

	// Generate and send a JWT token
	token, err := generateToken(ctx, user)
	if err != nil {
		log.Printf("Failed to generate token: %v", err)
		http.Error(w, "Failed to generate token", http.StatusInternalServerError)
		return
	}

	response := map[string]interface{}{
		"token":   token,
		"message": "Login successful",
		"user":    user,
	}
	log.Println("Token Generated and sended in response")
	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(response)
}

// getUserByEmail retrieves user data from Firestore based on the provided email.
func getUserByEmail(ctx context.Context, firestoreClient *firestore.Client, email string) (*User, error) {
	iter := firestoreClient.Collection("users").Where("Email", "==", email).Limit(1).Documents(ctx)
	defer iter.Stop()

	for {
		snapshot, err := iter.Next()
		if err != nil {
			if err == iterator.Done {
				// Email not found
				return nil, fmt.Errorf("user with email %s not found", email)
			}
			// Error while fetching the next document
			return nil, fmt.Errorf("error fetching user: %v", err)
		}

		// Found a matching document, parse it into a User struct
		var user User
		if err := snapshot.DataTo(&user); err != nil {
			return nil, fmt.Errorf("error parsing user data: %v", err)
		}

		return &user, nil
	}
}

// generateToken creates a JWT token with RS256 signing.
func generateToken(ctx context.Context, user *User) (string, error) {
	// Fetch private key content from Secret Manager
	privateKeyContent, err := fetchPrivateKeyContentFromSecretManager(ctx)
	if err != nil {
		return "", fmt.Errorf("failed to fetch private key content: %v", err)
	}

	privateKey, err := jwt.ParseRSAPrivateKeyFromPEM([]byte(privateKeyContent))
	if err != nil {
		return "", fmt.Errorf("failed to parse RSA private key: %v", err)
	}

	// Define JWT claims
	claims := jwt.MapClaims{
		"iss": "https://us-central1-capstore-takeoff.cloudfunctions.net/jwt_func", // Issuer of the token
		"sub": user.Email,                                                         // Subject (identity) of the token
		"aud": "capstone-takeoff@capstore-takeoff.iam.gserviceaccount.com",        // Audience that the token is intended for
		"iat": time.Now().Unix(),                                                  // Issued At time
		"exp": time.Now().Add(time.Hour * 24).Unix(),                              // Expiration time (1 hour in this case)
		// Add more claims as needed
	}

	// Create a new token with claims
	token := jwt.NewWithClaims(jwt.SigningMethodRS256, claims)

	// Sign the token with the RSA private key
	tokenString, err := token.SignedString(privateKey)
	if err != nil {
		return "", fmt.Errorf("failed to sign token: %v", err)
	}

	return tokenString, nil
}

// fetchPrivateKeyContentFromSecretManager retrieves the private key content from Secret Manager.
func fetchPrivateKeyContentFromSecretManager(ctx context.Context) (string, error) {
	// Initialize Secret Manager client
	client, err := secretmanager.NewClient(ctx)
	if err != nil {
		return "", fmt.Errorf("failed to create Secret Manager client: %v", err)
	}
	defer client.Close()

	// Fetch the secret version
	accessRequest := &secretmanagerpb.AccessSecretVersionRequest{
		Name: "projects/417888597975/secrets/privatersa/versions/latest",
	}
	secretResp, err := client.AccessSecretVersion(ctx, accessRequest)
	if err != nil {
		return "", fmt.Errorf("failed to access secret version: %v", err)
	}

	// Extract the secret payload
	payload := secretResp.Payload.Data

	return string(payload), nil
}
